import firebase from "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/analytics";
import "firebase/storage";

export const app = firebase.initializeApp({
  apiKey: "AIzaSyDWP0wtP0Z4XUqeqbhvYrmpyrN7EnLxpG4",
  authDomain: "meetmefit-bee25.firebaseapp.com",
  databaseURL: "https://meetmefit-bee25.firebaseio.com",
  projectId: "meetmefit-bee25",
  storageBucket: "meetmefit-bee25.appspot.com",
  messagingSenderId: "993130291852",
  appId: "1:993130291852:web:05bef528b65504e1ccd1a9",
  measurementId: "G-0XME24BVK1",
});
// Initialize Firebase

const auth = app.auth();
const db = app.firestore();
const analytics = app.analytics();

export default auth;
export { db };

// // Initialize Firebase
// const fire=firebase.initializeApp(firebaseConfig);
// // firebase.firestore().settings({ experimentalForceLongPolling: true });

// export default fire;
