import React from 'react';
import {useHistory} from "react-router-dom";
import "./Partnerships.css";
import fitnessCenter from "../Assets/partnerships-images/fitness-center-icon.svg";
import fitnessTrainer from "../Assets/partnerships-images/fitness-trainer-icon.svg";
import gym from "../Assets/partnerships-images/gym-icon.svg";
import nutritionist from "../Assets/partnerships-images/nutritionist-icon.svg";
import physiotherapist from "../Assets/partnerships-images/physiotherapist-icon.svg";
import yogaStudio from "../Assets/partnerships-images/yoga-studio-icon.svg";

export default function Partnerships() {
    
    const history =useHistory();
    
    function handleClick(){
        let path="/contact";
        history.push(path);
    }
    return (
        <div className="partnerships-div container">
            
            <div className="partnerships-firstdiv container">
                <h1 className="partnerships-firstdiv-heading">Partner with us!</h1>
            
            <div className="partnerships-grid-div row ">
                <div className="partnerships-grid-div-subdiv1 col-sm-12 col-md-6 col-lg-4">
                <img className="partnerships-grid-div-subdiv1-img img-fluid" src={gym} />
                </div>
                <div className="partnerships-grid-div-subdiv2 col-sm-12 col-md-6 col-lg-4">
                <img className="partnerships-grid-div-subdiv2-img img-fluid" src={yogaStudio} />
                </div>
                <div className="partnerships-grid-div-subdiv3 col-sm-12 col-md-6 col-lg-4">
                <img className="partnerships-grid-div-subdiv3-img img-fluid" src={fitnessCenter} />
                </div>
                <div className="partnerships-grid-div-subdiv4 col-sm-12 col-md-6 col-lg-4">
                <img className="partnerships-grid-div-subdiv4-img img-fluid" src={physiotherapist} />
                </div>
                <div className="partnerships-grid-div-subdiv5 col-sm-12 col-md-6 col-lg-4">
                <img className="partnerships-grid-div-subdiv5-img img-fluid" src={nutritionist} />
                </div>
                <div className="partnerships-grid-div-subdiv6 col-sm-12 col-md-6 col-lg-4">
                <img className="partnerships-grid-div-subdiv6-img img-fluid" src={fitnessTrainer} />
                </div>
            </div>
            </div>

            <div className="partnerships-seconddiv container">
                <p className="partnerships-seconddiv-para1">If you offer any one of the above services,MeetMeFit is the perfect platform for your products!</p>
                <p className="partnerships-seconddiv-para2">The partnerships can be mutually beneficial to create a community of people driven towards fitness that help each-other get fit and stay fit by the use of our Fitness Buddy Service.</p>
                <p className="partnerships-seconddiv-para3">To know more about our Partnerships</p>
                <button className="partnerships-seconddiv-button" onClick={handleClick}>Contact Us</button>
            </div>
        </div>
    )
}
