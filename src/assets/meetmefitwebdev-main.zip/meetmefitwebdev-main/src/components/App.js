import React from "react";
import "./App.css";
import "../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../../node_modules/bootstrap/dist/js/bootstrap.bundle";
import { Switch, Route } from "react-router-dom";
import Header from "./Header/Header";
import Home from "./Home/Home";
import Partnerships from "./Partnerships/Partnerships";
import About from "./About/About";
import Contact from "./Contact/Contact";
import Footer from "./Footer/Footer";
import TermsOfService from "./Footer/TermsOfService/TermsOfService";
import PrivacyPolicy from "./Footer/PrivacyPolicy/PrivacyPolicy";
import CommunityGuidelines from "./Footer/CommunityGuidelines/CommunityGuidelines";
import Careers from "./Footer/Careers/Careers";
import SafetyCenter from "../components/Footer/SafetyCenter/SafetyCenter";
import ScrollToTop from "../components/ScrollToTop";
import ErrorPage from "../components/ErrorPage/ErrorPage";

function App() {
  return (
    <div>
      <ScrollToTop />
      <Header />
      <Switch>
        <Route exact path="/" component={Home} />
        <Route exact path="/partnerships" component={Partnerships} />
        <Route exact path="/about" component={About} />
        <Route exact path="/contact" component={Contact} />
        <Route exact path="/terms-of-service" component={TermsOfService} />
        <Route exact path="/privacy-policy" component={PrivacyPolicy} />
        <Route exact path="/careers" component={Careers} />
        <Route
          exact
          path="/community-guidelines"
          component={CommunityGuidelines}
        />
        <Route exact path="/safety-center" component={SafetyCenter} />
        <Route component={ErrorPage}></Route>
      </Switch>
      <Footer />
    </div>
  );
}

export default App;
