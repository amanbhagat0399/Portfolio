import React, { useState, useEffect, useRef } from "react";
import "./Home.css";
import girl from "../Assets/home-images/intro/homegirl.svg";
import playstore from "../Assets/home-images/intro/playstore.svg";
import appstore from "../Assets/home-images/intro/appstore.svg";
import Signup from "../Assets/home-images/howitworks/signupicon.svg";
import Setpreferences from "../Assets/home-images/howitworks/setpreferencesicon.svg";
import Makefitnessbuddies from "../Assets/home-images/howitworks/makefitnessbuddiesicon.svg";
import Workoutvirtually from "../Assets/home-images/howitworks/workoutvirtuallyicon.svg";
import lines from "../Assets/background-images/lines-graphic.svg";
import circle from "../Assets/background-images/circle-dotted.svg";
import servicesbg1 from "../Assets/home-images/services/fitness-buddy-photo.jpg";
import servicesbg2 from "../Assets/home-images/services/gym-squad-photo.jpg";
import servicesbg3 from "../Assets/home-images/services/money-photo.jpg";
import CountUp from "react-countup";
import Flippy, { FrontSide, BackSide } from "react-flippy";
import servicesCardbg from "../Assets/home-images/services/services-cardbg.png";
import VisibilitySensor from "react-visibility-sensor";
import AOS from "aos";
import "aos/dist/aos.css";

export default function Home() {
  const ref = useRef();

  useEffect(() => {
    AOS.init({ duration: 2000 });
    AOS.refresh();
  }, []);

  function handleSignupBeta() {
    window.location.href =
      "https://play.google.com/store/apps/details?id=com.mmf.meetmefit";
  }

  return (
    <div>
      <div className="container">
        <div className="intro-div container">
          {/* INTRODUCTION */}
          <h1 className="introheading">Find the Best Fitness Buddies on</h1>

          <div className="intro-subdiv1">
            <h1 className="intro-subdiv1-heading1">MEET ME FIT</h1>
            <h3 className="intro-subdiv1-heading2">
              Meet&nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp;Workout
              &nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;&nbsp;Motivate
            </h3>
          </div>
          <div className="intro-subdiv2">
            <p className="intro-subdiv2-p1">
              Having issues with being consistent in workouts?
            </p>
            <p className="intro-subdiv2-p2">Well, say no more!</p>
            <p className="intro-subdiv2-p3">
              Signup with MeetMeFit Beta to find the best fitness buddies in
              town.
            </p>
            <button className="intro-subdiv2-beta" onClick={handleSignupBeta}>
              Install Now
            </button>

            <p className="intro-subdiv2-available">Available on</p>
            <img
              className="intro-subdiv2-play"
              src={playstore}
              alt="playstore"
            />
            <p className="intro-subdiv2-coming">Coming soon on</p>
            <img className="intro-subdiv2-app " src={appstore} alt="appstore" />
          </div>

          <img
            className="introhomephoto img-fluid"
            src={girl}
            alt="homeimage"
          />
        </div>

        <img
          className="home-background-lines"
          src={lines}
          alt="background-lines"
        />

        {/* VISION */}
        <div className="vision-div container">
          <h1 className="visionheading">
            Why you should find a Fitness buddy!
          </h1>

          <div className="vision-grid-div row ">
            <div className="vision-subdiv1 col-sm-12 col-md-12 col-lg-4">
              <h4
                // data-aos="vision-animation"
                className="vision-subdiv1-heading "
              >
                <CountUp start={0} end={50} duration={8} suffix="%" />
              </h4>

              <p className="vision-subdiv1-para ">
                People stop working out because of the Lack of Motivation
              </p>
            </div>
            <div className="vision-subdiv2 col-sm-12 col-md-12 col-lg-4 ">
              <h4 className="vision-subdiv2-heading ">
                <CountUp start={0} end={14} duration={8} suffix="%" />
              </h4>
              <p className="vision-subdiv2-para ">
                People stop working out because they are clueless about where to
                start
              </p>
            </div>
            <div className="vision-subdiv3 col-sm-12 col-md-12 col-lg-4">
              <h4 className="vision-subdiv3-heading ">
                <CountUp start={0} end={30} duration={8} suffix="%" />
              </h4>
              <p className="vision-subdiv3-para ">
                People are very inconsistent with their workouts
              </p>
            </div>
          </div>

          <p className="vision-div-para">
            Data from a Survey done by GymPik in 2019 across 5 metropolitan
            cities in India with a sample size of 1.6 million people.
          </p>
        </div>
        {/* HOW IT WORKS */}
        <div className="howitworks-div container">
          <h1 className="howitworksheading">How it works</h1>

          <div className="howitworks-grid-div row ">
            <div className="howitworks-subdiv1  col-sm-12 col-md-12 col-lg-3">
              <img
                className="howitworkssignup"
                src={Signup}
                alt="howitworkssignup"
              />
              <h4 className="howitworks-subdiv1-heading">Sign Up</h4>
              <p className="howitworks-subdiv1-para ">
                Create an Account on MeetMeFit App
              </p>
            </div>
            <div className="howitworks-subdiv2 col-sm-12 col-md-12 col-lg-3">
              <img
                className="howitworkssetpreferences"
                src={Setpreferences}
                alt="howitworkssetpreferences"
              />
              <h4 className="howitworks-subdiv2-heading ">Set Preferences</h4>
              <p className="howitworks-subdiv2-para ">
                Set the kind of fitness buddies you want to meet
              </p>
            </div>
            <div className="howitworks-subdiv3  col-sm-12 col-md-12 col-lg-3">
              <img
                className="howitworksmakefitnessbuddies"
                src={Makefitnessbuddies}
                alt="howitworksmakefitnessbuddies"
              />
              <h4 className="howitworks-subdiv3-heading ">
                Make Fitness Buddies
              </h4>
              <p className="howitworks-subdiv3-para ">
                Match with fitness buddies on MeetMeFit
              </p>
            </div>
            <div className="howitworks-subdiv4  col-sm-12 col-md-12 col-lg-3">
              <img
                className="howitworksworkoutvirtually"
                src={Workoutvirtually}
                alt="howitworksworkoutvirtually"
              />
              <h4 className="howitworks-subdiv4-heading ">
                Meet for a Workout or Workout Virtually
              </h4>
              <p className="howitworks-subdiv4-para ">
                Schedule Workout with your buddy
              </p>
            </div>
          </div>
        </div>

        <img
          className="background-circle"
          src={circle}
          alt="background-circle"
        />

        <div className="services-div container">
          <h1 className="services-div-heading">Services</h1>
          <p className="services-div-para1">Fitness made easy</p>
          <p className="services-div-para2">
            Get fit from home from the varied services that we provide.
            <span className="services-div-para2-text">
              Hover on the images to know more.
            </span>
            <span className="services-div-para2-mobile-text">
              Click on the images to know more.
            </span>
          </p>

          <div className="services-div-grid-div">
            <div className="row m-auto">
              <div className="col-sm-12 col-md-6 col-lg-4">
                <Flippy
                  flipOnHover={true}
                  flipOnClick={false}
                  flipDirection="horizontal"
                  ref={ref}
                >
                  <FrontSide
                    style={{
                      padding: "0",
                    }}
                    className="frontside1"
                  >
                    <img
                      src={servicesbg1}
                      alt="Avatar"
                      className="frontside-img1"
                    />
                  </FrontSide>
                  <BackSide
                    style={{
                      padding: "0",
                      backgroundColor: "black",
                    }}
                    className="backside1"
                  >
                    <img
                      src={servicesCardbg}
                      alt="Avatar"
                      className="backside-img1"
                    />
                    <h5 className="heading1">MEET FITNESS BUDDIES</h5>
                    <p className="para1">
                      Meet and Workout with experienced fitness buddies and stop
                      procrastinating.
                    </p>
                  </BackSide>
                </Flippy>
              </div>

              <div className="col-sm-12 col-md-6 col-lg-4">
                <Flippy
                  flipOnHover={true}
                  flipOnClick={false}
                  flipDirection="horizontal"
                  ref={ref}
                >
                  <FrontSide
                    style={{
                      padding: "0",
                    }}
                    className="frontside2"
                  >
                    <img
                      src={servicesbg2}
                      alt="Avatar"
                      className="frontside-img2"
                    />
                  </FrontSide>
                  <BackSide
                    style={{
                      padding: "0",
                      backgroundColor: "black",
                    }}
                    className="backside2"
                  >
                    <img
                      src={servicesCardbg}
                      alt="Avatar"
                      className="backside-img2"
                    />
                    <h5 class="heading2">WORKOUT</h5>
                    <p className="para2">
                      Schedule in-person or virtual workouts with your fitness
                      buddies from the MeetMeFit App.
                    </p>
                  </BackSide>
                </Flippy>
              </div>

              <div className="col-sm-12 col-md-6 col-lg-4">
                <Flippy
                  flipOnHover={true}
                  flipOnClick={false}
                  flipDirection="horizontal"
                  ref={ref}
                >
                  <FrontSide
                    style={{
                      padding: "0",
                    }}
                    className="frontside3"
                  >
                    <img
                      src={servicesbg3}
                      alt="Avatar"
                      className="frontside-img3"
                    />
                  </FrontSide>
                  <BackSide
                    style={{
                      padding: "0",
                      backgroundColor: "black",
                    }}
                    className="backside3"
                  >
                    <img
                      src={servicesCardbg}
                      alt="Avatar"
                      className="backside-img3"
                    />
                    <h5 class="heading3">FIND SPORT PARTNERS</h5>
                    <p className="para3">
                      Find people to play sports and go out on other activities
                      with you!
                    </p>
                  </BackSide>
                </Flippy>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
