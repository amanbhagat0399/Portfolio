import React, { useEffect } from "react";
import "./About.css";
import { useHistory, useLocation } from "react-router-dom";
import krati from "../Assets/about-images/krati.png";
import Aakanksha from "../Assets/about-images/Aakanksha.png";
import Akshata from "../Assets/about-images/Akshata.png";
import Bipin from "../Assets/about-images/Bipin.png";
import Tanay from "../Assets/about-images/Tanay.png";
import Ninad from "../Assets/about-images/Ninad.png";
import Adarsh from "../Assets/about-images/Adarsh.png";
import Malik from "../Assets/about-images/Malik.png";
import Anubhav from "../Assets/about-images/Anubhav.png";
import Yash from "../Assets/about-images/Yash.png";

export default function About() {
  const history = useHistory();

  function handleClick() {
    let path = "/contact";
    history.push(path);
  }

  return (
    <div className="about-div container">
      <div className="about-first-div container">
        <h1 className="about-first-div-heading">About us</h1>

        <div className="about-first-div-textdiv">
          <p className="about-first-div-textdiv-para1">
            MeetMeFit is a platform that is best suited for all types of people
            who have felt demotivated or just need a push from another person
            while working out.
          </p>
          <p className="about-first-div-textdiv-para2">
            MeetMeFit won't just help people build their bodies aesthetically
            but also holds the potential to provide people with an opportunity
            to live a healthier life with their fitness Buddies.
          </p>
          <p className="about-first-div-textdiv-para3">
            At MeetMeFit, we believe that people can grow faster if they have
            similar goals and work on them together and hence at MeetMeFit by
            letting our users find Buddies we are working to
            <b className="about-first-div-textdiv-para3-hashtag">
              #MakeThisWorldAFitterPlace
            </b>
          </p>
          <p className="about-first-div-textdiv-para4">
            <b>To know more about us</b>
          </p>
          <button
            className="about-first-div-textdiv-contactbutton"
            onClick={handleClick}
          >
            Contact us
          </button>
        </div>
      </div>

      <div className="about-second-div container">
        <h1 className="about-second-div-heading">Our Team</h1>
        <div className="about-second-div-griddiv row ">
          <div className="about-second-div-griddiv-subdiv1 col-sm-12 col-md-6 col-lg-4">
            <img
              className="about-second-div-griddiv-subdiv1-img"
              src={Yash}
              alt="yash"
            />
            <h4 className="about-second-div-griddiv-subdiv1-heading">
              Yash Randive
            </h4>
            <p className="about-second-div-griddiv-subdiv1-para">
              <b>Founder & Director</b>
            </p>
          </div>

          <div className="about-second-div-griddiv-subdiv2 col-sm-12 col-md-6 col-lg-4">
            <img
              className="about-second-div-griddiv-subdiv2-img"
              src={krati}
              alt="krati"
            />
            <h4 className="about-second-div-griddiv-subdiv2-heading">
              Krati Agrawal
            </h4>
            <p className="about-second-div-griddiv-subdiv2-para">
              <b>Marketing</b>
            </p>
          </div>

          <div className="about-second-div-griddiv-subdiv3 col-sm-12 col-md-6 col-lg-4">
            <img
              className="about-second-div-griddiv-subdiv3-img"
              src={Aakanksha}
              alt="Aakanksha"
            />
            <h4 className="about-second-div-griddiv-subdiv3-heading">
              Aakanksha Singh
            </h4>
            <p className="about-second-div-griddiv-subdiv3-para">
              <b>Data Science</b>
            </p>
          </div>

          <div className="about-second-div-griddiv-subdiv4 col-sm-12 col-md-6 col-lg-4">
            <img
              className="about-second-div-griddiv-subdiv4-img"
              src={Akshata}
              alt="Akshata"
            />
            <h4 className="about-second-div-griddiv-subdiv4-heading">
              Akshata Shrivastava
            </h4>
            <p className="about-second-div-griddiv-subdiv4-para">
              <b>Marketing</b>
            </p>
          </div>

          <div className="about-second-div-griddiv-subdiv5 col-sm-12 col-md-6 col-lg-4">
            <img
              className="about-second-div-griddiv-subdiv5-img"
              src={Bipin}
              alt="Bipin"
            />
            <h4 className="about-second-div-griddiv-subdiv5-heading">
              Bipin Dussa
            </h4>
            <p className="about-second-div-griddiv-subdiv5-para">
              <b>UI/UX Designer</b>
            </p>
          </div>

          <div className="about-second-div-griddiv-subdiv6 col-sm-12 col-md-6 col-lg-4">
            <img
              className="about-second-div-griddiv-subdiv6-img"
              src={Ninad}
              alt="Ninad"
            />
            <h4 className="about-second-div-griddiv-subdiv6-heading">
              Ninad Walanj
            </h4>
            <p className="about-second-div-griddiv-subdiv6-para">
              <b>Web Development</b>
            </p>
          </div>

          <div className="about-second-div-griddiv-subdiv7 col-sm-12 col-md-6 col-lg-4">
            <img
              className="about-second-div-griddiv-subdiv7-img"
              src={Adarsh}
              alt="Adarsh"
            />
            <h4 className="about-second-div-griddiv-subdiv7-heading">
              Adarsh Raj
            </h4>
            <p className="about-second-div-griddiv-subdiv7-para">
              <b>App Development</b>
            </p>
          </div>

          <div className="about-second-div-griddiv-subdiv8 col-sm-12 col-md-6 col-lg-4">
            <img
              className="about-second-div-griddiv-subdiv8-img"
              src={Malik}
              alt="Malik"
            />
            <h4 className="about-second-div-griddiv-subdiv8-heading">
              M.K. Malik
            </h4>
            <p className="about-second-div-griddiv-subdiv8-para">
              <b>App Development</b>
            </p>
          </div>

          <div className="about-second-div-griddiv-subdiv9 col-sm-12 col-md-6 col-lg-4">
            <img
              className="about-second-div-griddiv-subdiv9-img"
              src={Anubhav}
              alt="Anubhav"
            />
            <h4 className="about-second-div-griddiv-subdiv9-heading">
              Anubhav Sharma
            </h4>
            <p className="about-second-div-griddiv-subdiv9-para">
              <b>Data Science</b>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
