import React from "react";
import { Link, NavLink } from "react-router-dom";
import logo from "../Assets/logo.svg";
import "./Header.css";

export default function Header() {
  return (
    <div className="header-main-div">
      <nav className="navbar navbar-expand-lg navbar-light">
        <div className="container mt-sm-3 mt-md-3 mt-lg-3 ">
          <Link className="logolink " to="/">
            <img className="logo1" src={logo} alt="logo" />
          </Link>
          <button
            className="navbar-toggler "
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
              <li className="navbar-item-1 nav-item me-lg-5 mt-sm-3 mt-md-3 mt-lg-2">
                <NavLink
                  className="link1"
                  to="/"
                  exact
                  activeClassName="link1-active"
                >
                  HOME
                </NavLink>
              </li>
              <li className="navbar-item-2 nav-item me-lg-5 mt-sm-3 mt-md-3 mt-lg-2">
                <NavLink
                  className="link2"
                  to="/partnerships"
                  exact
                  activeClassName="link2-active"
                >
                  PARTNERSHIPS
                </NavLink>
              </li>
              <li className="navbar-item-3 nav-item me-lg-5 mt-sm-3 mt-md-3 mt-lg-2">
                <NavLink
                  className="link3"
                  to="/about"
                  exact
                  activeClassName="link3-active"
                >
                  ABOUT
                </NavLink>
              </li>
              <li className="navbar-item-4 nav-item me-lg-5 mt-sm-3 mt-md-3 mt-lg-2">
                <NavLink
                  className="link4"
                  to="/contact"
                  exact
                  activeClassName="link4-active"
                >
                  CONTACT
                </NavLink>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  );
}
