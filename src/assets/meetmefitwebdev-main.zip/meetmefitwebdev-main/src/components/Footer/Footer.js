import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Footer.css";
import { db } from "../../Firebase";
import facebooklogo from "../Assets/footer/facebooklogo.svg";
import twitterlogo from "../Assets/footer/twitterlogo.svg";
import instagramlogo from "../Assets/footer/instagramlogo.svg";
import emaillogo from "../Assets/footer/emaillogo.svg";
import lines from "../Assets/background-images/lines-graphic.svg";
import emailjs from "emailjs-com";

function Footer() {
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState({});

  function handleInput(e) {
    e.preventDefault();
    setEmail(e.target.value);
  }

  function validation() {
    const emailError = {};
    let isValid = true;

    //emailvalidation
    if (email.length === 0) {
      emailError.empty = "Email is required";
      isValid = false;
    } else if (!email.includes("@")) {
      emailError.nothave1 = "Email is invalid";
      isValid = false;
    } else if (!email.includes(".")) {
      emailError.nothave2 = "Email is invalid";
      isValid = false;
    } else if (email.indexOf("@") <= 0) {
      emailError.nothave3 = "Email is invalid";
      isValid = false;
    } else if (
      email.charAt(email.length - 4) !== "." &&
      email.charAt(email.length - 3) !== "."
    ) {
      emailError.nothave3 = "Email is invalid";
      isValid = false;
    }

    setEmailError(emailError);
    return isValid;
  }

  function handleClick(e) {
    e.preventDefault();
    console.log("clicked");
    const isValid = validation();

    if (isValid === true) {
      //DATABASE QUERY
      db.collection("latestUpdates-mmf-web")
        .add({
          email: email,
        })
        .then((doc) => {
          window.alert("Email Submitted");
          // EMAILJS
          var service_id = "service_u43uxhn";
          var template_id = "template_njdwjzc";
          var user_id = "user_DmmT54aP5y3WBxODpCKJc";
          var params = {
            to_email: email,
          };

          emailjs.send(service_id, template_id, params, user_id).then(
            (result) => {
              console.log(result.text);
            },
            (error) => {
              console.log(error);
            }
          );
        })
        .catch((error) => {
          console.error("Error adding document: ", error);
        });
      setEmail("");
    }
  }

  return (
    <div className="container">
      <div className="footer-first-div ">
        <h2 className="footer-first-div-heading">Get the Latest Updates</h2>
        <input
          type="email"
          autoComplete="off"
          className="footer-first-div-input"
          placeholder="Enter your email"
          value={email}
          onChange={handleInput}
          required={true}
        />

        {Object.keys(emailError).map((x) => {
          return (
            <div key={x} className="footer-first-div-input-error">
              {emailError[x]}
            </div>
          );
        })}

        <button className="footer-subscribe" onClick={handleClick}>
          Subscribe
        </button>

        <p className="footer-first-div-para ">
          By subscribing, you agree to the
          <Link to="/terms-of-service" className="footer-first-div-para-link1 ">
            Terms of Service
          </Link>
          and
          <Link to="/privacy-policy" className="footer-first-div-para-link2">
            Privacy Policy.
          </Link>
        </p>
      </div>

      <div className="footer-second-div">
        <div className="footer-grid-second-div row">
          <div className="facebook-icon col-sm-2 col-lg-1">
            <a
              href="https://www.facebook.com/meetmefitcommunity"
              target="_blank"
              rel="noreferrer"
            >
              <img
                className="footer-facebooklogo"
                src={facebooklogo}
                alt="Facebook"
              />
            </a>
          </div>
          <div className="twitter-icon col-sm-2 col-lg-1">
            <a
              href="https://twitter.com/meetmefit"
              target="_blank"
              rel="noreferrer"
            >
              <img
                className="footer-twitterlogo"
                src={twitterlogo}
                alt="Twitter"
              />
            </a>
          </div>
          <div className="instagram-icon col-sm-2 col-lg-1 ">
            <a
              href="https://www.instagram.com/meetmefitcommunity/"
              target="_blank"
              rel="noreferrer"
            >
              <img
                className="footer-instagramlogo"
                src={instagramlogo}
                alt="Instagram"
              />
            </a>
          </div>
          <div className="email-icon col-sm-2 col-lg-1 ">
            <a href="mailto:hello@meetmefit.com">
              <img className="footer-emaillogo" src={emaillogo} alt="Email" />
            </a>
          </div>
        </div>
      </div>

      <div className="footer-third-div">
        <div className="footer-grid-third-div  row">
          {/* first subdiv */}
          <div className="footer-subdiv1 col-sm-12 col-md-4 col-lg-4">
            <h3 className="footer-third-div-header1">Company</h3>

            <p className="footer-third-subdiv1-para1">
              <Link to="/about" className="footer-third-subdiv1-para1-link">
                About us
              </Link>
            </p>

            <p className="footer-third-subdiv1-para3">
              <Link to="/careers" className="footer-third-subdiv1-para3-link">
                Careers
              </Link>
            </p>

            <p className="footer-third-subdiv1-para4">
              <Link to="/contact" className="footer-third-subdiv1-para4-link">
                Contact us
              </Link>
            </p>
          </div>

          {/* Second subdiv */}
          <div className="footer-subdiv2 col-sm-12 col-md-4 col-lg-4">
            <h3 className="footer-third-subdiv2-header1 ">Support</h3>

            <p className="footer-third-subdiv2-para2 ">
              <Link
                to="/safety-center"
                className="footer-third-subdiv2-para2-link"
              >
                Safety Center
              </Link>
            </p>
            <p className="footer-third-subdiv2-para3">
              <Link
                to="/community-guidelines"
                className="footer-third-subdiv2-para3-link"
              >
                Community Guidelines
              </Link>
            </p>
          </div>

          {/* third subdiv */}
          <div className="footer-subdiv3 col-sm-12 col-md-4 col-lg-4">
            <h3 className="footer-third-subdiv3-header1 ">Legal</h3>

            <p className="footer-third-subdiv3-para2">
              <Link
                to="/privacy-policy"
                className="footer-third-subdiv3-para2-link"
              >
                Privacy Policy
              </Link>
            </p>

            <p className="footer-third-subdiv3-para3">
              <Link
                to="/terms-of-service"
                className="footer-third-subdiv3-para3-link"
              >
                Terms of Service
              </Link>
            </p>
          </div>
        </div>
      </div>

      {/* copyright */}
      <p className="footer-copyright">© 2020 MeetMeFit Pvt Ltd</p>
    </div>
  );
}

export default Footer;
