import React from "react";
import "./PrivacyPolicy.css";

export default function PrivacyPolicy() {
  return (
    <div className="privacypolicy-div container">
      <div className="privacypolicy-div-first-subdiv">
        <h3 className="privacypolicy-div-first-subdiv-heading1">
          Introduction
        </h3>
        <p>
          Our privacy policy (the “Privacy Policy”) explains the information we
          collect, how we use and share it, how to manage your privacy controls
          and your rights in connection with our websites and the related mobile
          applications and services (collectively, the “Services”). Please also
          read our Terms of Service which sets out the terms governing the
          Services. MeetMeFit is headquartered in Thane, India and our Services
          are provided to you by MeetMeFit Pvt. Ltd. This policy was written in
          English. To the extent a translated version conflicts with the English
          version, the English version controls. Unless indicated otherwise,
          this Privacy Policy does not apply to third party products or services
          or the practices of companies that we do not own or control, including
          other companies you might interact with on or through the Services.
          Questions or comments about this Privacy Policy may be submitted by
          mail to hello@meetmefit.com
        </p>

        <h3 className="privacypolicy-div-first-subdiv-heading2">
          Information MeetMeFit Collects
        </h3>
        <p>
          MeetMeFit collects information about you, including information that
          directly or indirectly identifies you, if you or your other members
          choose to share it with MeetMeFit. We receive information in a few
          different ways, including when you track, complete or upload
          activities using the Services. MeetMeFit also collects information
          about how you use the Services. There are also several opportunities
          for you to share information about yourself, your friends, and your
          activities with MeetMeFit. For example:
        </p>

        <h3 className="privacypolicy-div-first-subdiv-heading3">
          Account, Profile, Activity, and Use Information
        </h3>
        <p>
          We collect basic account information such as your name, email address,
          date of birth, gender, weight, username and password that helps secure
          and provide you with access to our Services. Profile, activity and use
          information is collected about you when you choose to upload a
          picture, activity (including date, time and geo-location information
          as well as your steps, calories, heart rate and other health related
          parameters), join a challenge, view others’ activities, or otherwise
          use the Services. We use your contact information so we can respond to
          your support requests and comments.
        </p>

        <h3 className="privacypolicy-div-first-subdiv-heading4">
          Location Information
        </h3>
        <p>
          We collect and process location information when you sign up for and
          use the Services. We may or may not track your device location while
          you are not using MeetMeFit(it depends on the location permissions
          given by you to the app e.g. ‘Allow all the time’ or ‘Allow only while
          in use’ and equivalents of these on different devices and platforms),
          but in order to provide MeetMeFit’s core Services, it is necessary for
          us to track your device location while you use MeetMeFit. If you would
          like to stop the device location tracking, you may do so at any time
          by adjusting your device settings.
        </p>

        <h3 className="privacypolicy-div-first-subdiv-heading5">
          Content You Share
        </h3>
        <p>
          We gather information from the fit buddy requests, matches, chats,
          photos, posts, comments, likes, ratings, reviews, and other content
          you share on the Services, including when you participate in partner
          events or create fit buddy challenges.
        </p>

        <h3 className="privacypolicy-div-first-subdiv-heading6">
          Contacts Information
        </h3>
        <p>
          You can choose to add your contacts’ information by connecting your
          contacts from your mobile device or social networking accounts to
          MeetMeFit. If you choose to share your contacts with MeetMeFit,
          MeetMeFit will, in accordance with your instructions, access and store
          your contacts’ information in order to identify connections and help
          you connect with them.
        </p>

        <h3 className="privacypolicy-div-first-subdiv-heading7">
          Connected Devices and Apps
        </h3>
        <p>
          MeetMeFit collects information from devices and apps you connect to
          MeetMeFit. For example, you may connect your Google Fit or Apple
          Health account in order to view and provide Health Information.
          MeetMeFit may collect or infer health information. Certain health
          information may be inferred from sources such as heart rate or other
          measurements, including power, cadence, and weight or other
          indicators. Before you can upload health information to MeetMeFit, you
          must give your explicit consent to the processing of that health
          information by MeetMeFit. You can withdraw your consent to MeetMeFit
          processing your health information at any time.
        </p>

        <h3 className="privacypolicy-div-first-subdiv-heading8">
          Payment Information
        </h3>
        <p>
          When you make a payment on MeetMeFit, you may provide payment
          information such as your payment card details, Bank details, Credit
          Card details, ATM Card details, Debit card details or other payment
          details. We use Payment Card Industry compliant third-party payment
          services and we do not store your any payment card, Bank, Credit Card,
          ATM Card, Debit card or other payment information.
        </p>

        <h3 className="privacypolicy-div-first-subdiv-heading9">
          Third-Party Accounts
        </h3>
        <p>
          MeetMeFit allows you to sign up and log in to the Services using
          accounts you create with third-party products and services, such as
          Facebook, Google, or Apple (collectively, “Third-Party Accounts”). If
          you access the Services with Third-Party Accounts we will collect
          information that you have agreed to make available such as your name,
          email address, profile information and preferences. This information
          is collected by the Third-Party Account provider and is provided to
          MeetMeFit under their privacy policies. You can generally control the
          information that we receive from these sources using the privacy
          controls in your Third-Party Account.
        </p>

        <h3 className="privacypolicy-div-first-subdiv-heading10">
          Technical Information and Log Files
        </h3>
        <p>
          We collect information from your browser, computer, or mobile device,
          which provide us with technical information when you access or use the
          Services. This technical information includes device and network
          information, cookies, log files and analytics information. Learn more
          about how we use cookies and manage your preferences by visiting our
          Cookies Policy. The Services use log files. The information stored in
          those files includes IP addresses, browser type, internet service
          provider (ISP), referring/exit pages, platform type, date/time stamp,
          and number of clicks. This information is used to analyze trends,
          administer, protect and secure the Services, track member movement in
          the aggregate, and gather broad demographic information for aggregate
          use. IP addresses may be linked to session IDs, user IDs and device
          identifiers.
        </p>

        <h3 className="privacypolicy-div-first-subdiv-heading11">
          Other Information
        </h3>
        <p>
          We may collect information from you through third parties, such as
          when we collect your feedback through surveys. We may also collect
          information about you from other members such as when they send/accept
          you/your fit buddy request, chat, meet up with you or comment on your
          activities.
        </p>
      </div>

      <div className="privacypolicy-div-second-subdiv">
        <h3 className="privacypolicy-div-second-subdiv-heading1">
          How MeetMeFit Uses Information
        </h3>
        <h4 className="privacypolicy-div-second-subdiv-heading2">
          MeetMeFit uses the information we collect and receive as described
          below.
        </h4>
        <h5 className="privacypolicy-div-second-subdiv-subheading1">
          To provide the Services
        </h5>
        <p>
          We use the information we collect and receive to provide the Services,
          including providing you with the ability to:
        </p>
        <ul>
          <li>
            Suggest you Fit Buddies and Recommend you as a Fit Buddy to Others.
            For example, to give you the best experience of our Fit Buddy
            network, we use your interests like sports, preferred fit buddy
            gender, location, etc. in order to recommend you people in the
            MeetMeFit community you can buddy up with for workouts whilst using
            this information to suggest your profile to other MeetMeFit
            community members to buddy up with you.
          </li>
          <li>
            Interact with other Fit Buddies. For example, to buddy up, chat,
            video call and challenge other fit buddies on the platform.
          </li>
          <li>
            Manage your training. For example, to set goals and use your
            training dashboard.
          </li>
          <li>
            Reward you. For example, using steps, calories, number of meet-up’s
            to reward you with MeetMeFit Points, in-ap badges and other rewards
            provided by products and services partnered/associated with us.
          </li>
          <li>
            To visualize your activities in new ways. For example, by creating
            personal heat maps or using your training log.
          </li>
        </ul>
        <p>
          Subject to your privacy controls, your information, including parts of
          your profile, username, photos, members you match with and who match
          with you, Fit Buddy Squads you belong to, your activities, the devices
          you use, and likes and comments you give and receive will be shared on
          MeetMeFit so that you may be able to participate in the Services, for
          example to show your place on a leaderboard. Certain information
          (e.g., your name, and some profile information) is also available to
          non-members on the web. Your precise location information, such as how
          fa/ where you currently are, may also be shared on MeetMeFit or to
          non-members, in accordance with your privacy controls.
        </p>
        <h5 className="privacypolicy-div-second-subdiv-subheading2">
          To customize your experience
        </h5>
        <p>
          We use the information we collect about you, your Fit Buddies, and
          your activities to customize your experience. For example, we may
          suggest potential fit buddies, challenges, or fit buddy squads that
          may interest you, Verified Fit Buddies that you may want to match
          with, or new features that you may want to try. If we know that you
          like to perform a particular fitness activity, we may tell you about
          new fitness activities of your interest or show you sponsored content
          related to those activities. If we see that you exercise in a certain
          area, we may suggest a fitness centre, fitness buddy (‘ies’), partner
          services/products in that area.
        </p>
        <h5 className="privacypolicy-div-second-subdiv-subheading3">
          To protect you and the Services
        </h5>
        <p>
          We use the information we collect to protect members, enforce our
          Terms of Service and Community Guidelines, and promote safety. For
          example, we find and remove content that violates our terms, such as
          hate speech or spam, as well as suspend or terminate accounts that
          share such content.
        </p>
        <h5 className="privacypolicy-div-second-subdiv-subheading4">
          To improve our Services
        </h5>
        <p>
          We also use the information we collect to analyze, develop and improve
          the Services. To do this, MeetMeFit may use third-party analytics
          providers to gain insights into how our Services are used and to help
          us improve the Services.
        </p>
        <h5 className="privacypolicy-div-second-subdiv-subheading5">
          To communicate with you
        </h5>
        <p>
          We use the information we collect to provide support in response to
          your requests and comments. We may also use the information we collect
          to market and promote the Services, activities and events on
          MeetMeFit, and other commercial products or services. This includes
          marketing and push communications, where you have not opted out of
          receiving such messages and notifications.
        </p>
        <h5 className="privacypolicy-div-second-subdiv-subheading6">
          To process your subscription
        </h5>
        <p>We use the information we collect to process your subscription.</p>

        <h3 className="privacypolicy-div-second-subdiv-heading3">
          Aggregate Information
        </h3>
        <p>
          We do not rent, sell or share your personal information to third
          parties except where We have permission from you in cases where we
          have to provide services requested / ordered by you, we have to help
          to investigate, prevent or take action regarding unlawful and illegal
          activities, suspected fraud, potential threat to the safety or
          security of any person or organization, property or asset or rights of
          the Website/Mobile Application from unauthorized use or misuse of the
          Website/Mobile Application, violations of terms of use to defend the
          site against legal claims/proceedings arising out of special
          circumstances including but not limited to meeting requirements of
          court orders, judicial proceedings, or other legal processes; enforce
          the terms of use or terms of this policy of the Website/ Mobile
          Application.
        </p>
        <h3 className="privacypolicy-div-second-subdiv-heading4">
          Service Providers
        </h3>
        <p>
          We may share your information with third parties who provide services
          to MeetMeFit such as supporting, improving, promoting and securing the
          Services, processing payments, or fulfilling orders. These service
          providers only have access to the information necessary to perform
          these limited functions on our behalf and are required to protect and
          secure your information. We may also engage service providers to
          collect information about your use of the Services over time on our
          behalf, so that we or they may promote MeetMeFit or display
          information that may be relevant to your interests on the Services or
          other websites or services.
        </p>
        <h3 className="privacypolicy-div-second-subdiv-heading5">
          Publicly Available Information
        </h3>
        <p>
          When you join the MeetMeFit community, your profile and your
          activities are set to be viewable by everyone by default. Your name
          and other profile information is viewable by other MeetMeFit members
          and the public and, subject to your privacy controls, additional
          information and content you share may also be viewable. For example,
          your photos and routes may be accessed by other MeetMeFit members and
          non-members or viewable on publicly accessible MeetMeFit pages or in
          search engine results.
        </p>
        <h3 className="privacypolicy-div-second-subdiv-heading6">
          Sharing Information and Activities
        </h3>
        <p>
          As a social network, we share your information with other MeetMeFit
          members and the public in accordance with your privacy controls. You
          can change the visibility of the activities you upload to MeetMeFit.
          You can also share your activities with your contacts via text, email,
          or on social media applications like Facebook, Instagram, and Twitter.
          If you link your MeetMeFit account to other social networks and share
          your activities, they will be viewable on such third-party platforms,
          including your location information. You should use caution when
          sharing information via third parties and you should carefully review
          the privacy practices of such third parties.
        </p>
        <h3 className="privacypolicy-div-second-subdiv-heading7">
          ​Third Party Business via API or Other Integrations
        </h3>
        <p>
          We enable you to share your information and content with third party
          apps, plugins, or websites that integrate with the Services, as well
          as with third parties who work with MeetMeFit to offer an integrated
          feature, such as a challenge sponsor. You can choose to share your
          profile data and activity data (including private activities).
          Information collected by these third parties is subject to their terms
          and policies. MeetMeFit is not responsible for the terms or policies
          of third parties.
        </p>
        <h3 className="privacypolicy-div-second-subdiv-heading8">
          Affiliates and Acquirors of our Business or Assets
        </h3>
        <p>
          We may share your information with affiliates under common control
          with us, who are required to comply with the terms of this Privacy
          Policy with regard to your information. If MeetMeFit becomes involved
          in a business combination, securities offering, bankruptcy,
          reorganization, dissolution or other similar transaction, we may share
          or transfer your information in connection with such transaction.
        </p>
        <h3 className="privacypolicy-div-second-subdiv-heading9">
          Legal Requirements
        </h3>
        <p>
          We may preserve and share your information with third parties,
          including law enforcement, public or governmental agencies, or private
          litigants, within or outside your country of residence, if we
          determine that such disclosure is allowed by the law or reasonably
          necessary to comply with the law, including to respond to court
          orders, warrants, subpoenas, or other legal or regulatory process. We
          may also retain, preserve or disclose your information if we determine
          that this is reasonably necessary or appropriate to prevent any person
          from death or serious bodily injury, to address issues of national
          security or other issues of public importance, to prevent or detect
          violations of our Terms of Service or fraud or abuse of MeetMeFit or
          its members, or to protect our operations or our property or other
          legal rights, including by disclosure to our legal counsel and other
          consultants and third parties in connection with actual or potential
          litigation.
        </p>
        <h3 className="privacypolicy-div-second-subdiv-heading10">
          DMCA Notices
        </h3>
        <p>
          We may share your information with third parties when we forward
          Digital Millennium Copyright Act (DMCA) notifications, which will be
          forwarded as submitted to us without any deletions.
        </p>
        <h3 className="privacypolicy-div-second-subdiv-heading11">
          How We Protect Information
        </h3>
        <p>
          We take several measures to safeguard the collection, transmission and
          storage of the data we collect. We employ reasonable protections for
          your information that are appropriate to its sensitivity. The Services
          use industry standard Secure Sockets Layer (SSL) technology to allow
          for the encryption of personal information and credit card numbers.
          MeetMeFit engages providers that are industry leaders in online
          security, including Services verification, to strengthen the security
          of our Services. The Services are registered with site identification
          authorities so that your browser can confirm MeetMeFit’s identity
          before any personal information is sent. In addition, MeetMeFit’s
          secure servers protect this information using advanced firewall
          technology.
        </p>
      </div>

      <div className="privacypolicy-div-third-subdiv">
        <h3 className="privacypolicy-div-third-subdiv-heading1">
          Managing Your Settings
        </h3>

        <h4 className="privacypolicy-div-third-subdiv-subheading1">
          Privacy Controls
        </h4>
        <p>
          MeetMeFit offers several features and settings to help you manage your
          privacy and share your activities. Most privacy controls are located
          in your privacy controls page, but some are specific to individual
          activities, fit buddies, members. MeetMeFit provides you the option to
          make your activities private.
        </p>
        <h4 className="privacypolicy-div-third-subdiv-subheading2">
          Adjust Notification and Email Preferences
        </h4>
        <p>
          MeetMeFit offers various ways to manage the notifications you receive.
          You can choose to stop receiving certain emails and notifications by
          indicating your preferences. You may also unsubscribe by following the
          instructions contained at the bottom of marketing or promotional
          emails. Any administrative or service-related emails (to confirm a
          purchase, or an update to this Privacy Policy or our Terms of Service,
          etc.) generally do not offer an option to unsubscribe as they are
          necessary to provide the Services you requested.
        </p>
        <h4 className="privacypolicy-div-third-subdiv-subheading3">
          Updating Account Information
        </h4>
        <p>
          You may correct, amend or update profile or account information at any
          time by adjusting that information in your account settings. If you
          need further assistance correcting inaccurate information, please
          contact MeetMeFit at hello@meetmefit.com.
        </p>
        <h4 className="privacypolicy-div-third-subdiv-subheading4">
          Deleting Information and Accounts
        </h4>
        <p>
          You can delete your account using our self-service tools. After you
          make a deletion request, we permanently and irreversibly delete your
          personal data from our systems, including backups. Once deleted, your
          data, including your account, activities and place on leaderboards
          cannot be reinstated. Following your deletion of your account, it may
          take up to 90 days to delete your personal information and system logs
          from our systems. Additionally, we may retain information where
          deletion requests are made to comply with the law and take other
          actions permitted by law. Note that content you have shared with
          others, such as photos, or that others have copied may also remain
          visible after you have deleted your account or deleted specific
          information from your own profile. Your public profile may be
          displayed in search engine results until the search engine refreshes
          its cache. MeetMeFit also provides you the option to remove individual
          activities you have posted without deleting your account. Once
          removed, the activities may remain on MeetMeFit’s systems until you
          delete your account.
        </p>
        <h4 className="privacypolicy-div-third-subdiv-subheading5">
          Your Rights and Our Legal Bases
        </h4>
        <p>
          We provide the same suite of privacy tools and controls to all of our
          members worldwide. Particular rights may be available to you if you
          reside in certain locations, such as the EEA, Brazil or California.
        </p>
        <h4 className="privacypolicy-div-third-subdiv-subheading6">
          Your Legal Rights in the EEA
        </h4>
        <p>
          If you are habitually located in the EEA, you have the right to
          access, rectify, download or erase your information, as well as the
          right to restrict and object to certain processing of your
          information.
        </p>

        <h3 className="privacypolicy-div-third-subdiv-heading2">
          Our Legal Bases
        </h3>
        <p>
          <p>
            MeetMeFit relies on a number of legal bases to collect, use, share,
            and otherwise process the information we have about you for the
            purposes described in this Privacy Policy, including:
          </p>
          <ul>
            <li>
              as necessary to provide the Services and fulfill our obligations
              pursuant to the Terms of Service. For example, we cannot provide
              the Services unless we collect and use your location information;
            </li>
            <li>where you have consented to the processing;</li>{" "}
            <li>
              where necessary to comply with a legal obligation, a court order,
              or to exercise and defend legal claims;
            </li>
            <li>
              to protect your vital interests, or those of others, such as in
              the case of emergencies; and
            </li>
            <li>
              where necessary for the purposes of MeetMeFit’s or a third party’s
              legitimate interests, such as our interests in protecting our
              members, our partners’ interests in collaborating with our
              members, and our commercial interests in ensuring the
              sustainability of the Services.
            </li>
          </ul>
        </p>
        <h3 className="privacypolicy-div-third-subdiv-heading3">Transfers</h3>
        <p>
          The Services are operated from India. If you are located outside of
          India and choose to use the Services or provide information to us, you
          acknowledge and understand that your information will be transferred,
          processed and stored in the Asia, as it is necessary to provide the
          Services and perform the Terms of Service. India’s privacy laws may
          not be as protective as those in your jurisdiction.
        </p>
        <h3 className="privacypolicy-div-third-subdiv-heading4">
          Retention of Information
        </h3>
        <p>
          We retain information as long as it is necessary to provide the
          Services to you and others, subject to any legal obligations to
          further retain such information. Information associated with your
          account will generally be kept until it is no longer necessary to
          provide the Services or until your account is deleted. In addition,
          you can delete some items of information (e.g., profile information)
          and you can remove individual activities from view on the Services
          without deleting your account. For example, after you withdraw your
          consent to MeetMeFit processing your health-related information,
          MeetMeFit will delete all health-related information you upload.
          Following your deletion of your account, it may take up to 90 days to
          fully delete your personal information and system logs from our
          systems. Additionally, we may retain information to comply with the
          law, prevent fraud, collect fees, resolve disputes, troubleshoot
          problems, assist with investigations, enforce the Terms of Service and
          take other actions permitted by law. The information we retain will be
          handled in accordance with this Privacy Policy. Information connected
          to you that is no longer necessary and relevant to provide our
          Services may be de-identified or aggregated with other non-personal
          data to provide insights which are commercially valuable to MeetMeFit,
          such as statistics of the use of the Services. For example, we may
          retain publicly available segments or routes and other depersonalized
          geolocation information to continue to improve the Services and we use
          aggregated information in MeetMeFit Metro and our Global Heatmap. This
          information will be de-associated with your name and other
          identifiers.
        </p>
        <h3 className="privacypolicy-div-third-subdiv-heading5">
          Information Security
        </h3>
        <p>
          MeetMeFit take appropriate security measures to protect against
          unauthorized access to or unauthorized alteration, disclosure or
          destruction of data and restrict access to personal information to our
          employees, contractors and agents who need to know that information in
          order to operate, develop or improve our services. These individuals
          are bound by confidentiality obligations and may be subject to
          discipline, including termination and criminal prosecution, if they
          fail to meet these obligations. Although we endeavor to safeguard the
          confidentiality of your personally identifiable information, however,
          transmissions made by means of the Internet cannot be made absolutely
          secure. By using this Site/Mobile Application, you agree that we will
          have no liability for disclosure of your information due to errors in
          transmission or unauthorized acts of third parties. You further agree
          that you are solely responsible and liable for, and shall indemnify us
          against any and all costs, expenses, damages, fees, etc. that
          MeetMeFit may incur or suffer due to any personal information or other
          materials that you post, upload, submit, and otherwise make available
          on the Website/Mobile Application. You will be yourself responsible
          for the personal information disclosed in public areas of the
          Website/Mobile Application and MeetMeFit will not be held responsible
          for use / misuse of such information shared with other persons in such
          public areas. Cookies A "cookie" is a small piece of information
          stored by a Web server on a Web browser so it can be later read back
          from that browser. Cookies are useful for enabling the browser to
          remember information specific to a given user. MeetMeFit places both
          permanent and temporary cookies in your computer's/mobile’s hard
          drive. These will not harm your computer/mobile phone in any way.
          MeetMeFit cookies do not contain any of your personally identifiable
          information. It only helps you retrieve your required information
          faster, and helps us give you more personalized service.
        </p>
        <h3 className="privacypolicy-div-third-subdiv-heading6">Waiver</h3>
        <p>
          No provision of this Agreement shall be deemed to be waived and no
          breach excused, unless such waiver or consent shall be in writing and
          signed by MeetMeFit. Any consent by MeetMeFit to, or a waiver by
          MeetMeFit of any breach by you, whether expressed or implied, shall
          not constitute consent to, waiver of, or excuse for any other
          different or subsequent breach.
        </p>
        <h3 className="privacypolicy-div-third-subdiv-heading7">Termination</h3>
        <p>
          We may terminate and/or suspend your registration immediately, without
          notice, if there has been a violation of these Terms & Conditions of
          Use or other policies and terms posted on the Site/Mobile Application
          by you or by someone using your Credentials. We may also cancel or
          suspend your registration for any other reason, including inactivity
          for an extended period, but will attempt to notify you in advance of
          such cancellation or suspension. MeetMeFit shall not be liable to you
          or any third party for any termination of your access to the Site/
          Mobile Application. Further, you agree not to attempt to use the
          Site/Mobile Application after any such deletion, deactivation or
          termination.
        </p>
        <h3 className="privacypolicy-div-third-subdiv-heading8">
          Indemnification
        </h3>
        <p>
          Upon a request by us, you agree to defend, indemnify, and hold
          harmless us, our employees, contractors, officers, directors, agents,
          parent, other affiliated companies, and suppliers, from all
          liabilities, claims, demands and expenses, including attorney’s fees,
          made by any third party that arise from or are related to (a) your
          access to the Site, or (b) the violation of these Terms & Conditions
          of Use by you or any third party using your Credentials of any
          intellectual property or other right of any person or entity. The
          foregoing indemnification obligation does not apply to liabilities,
          claims and expenses arising as a result of our own gross negligence or
          intentional misconduct.
        </p>
        <h3 className="privacypolicy-div-third-subdiv-heading9">
          Governing law
        </h3>
        <p>
          This Agreement shall, in all respects, be governed by and construed in
          all respects in accordance with the laws of India. Each of us hereby
          submits to the exclusive jurisdiction of the courts in Mumbai in
          connection with any dispute arising out of or in connection with this
          Agreement. Unless otherwise specified, the material on the Website/
          Mobile Application is presented solely for the purpose of sale in
          India. MeetMeFit makes no representation that materials on the
          Website/ Mobile Application are appropriate or available for use in
          other locations/countries other than India. Those who choose to access
          this site from other locations/countries other than India, they do so
          on their own initiative and MeetMeFit is not responsible for supply of
          goods/refund for the goods ordered from other locations/countries
          other than India which is compliance with local laws and to the extent
          that local laws are applicable. For Independent Auditor’s report and
          Compliance Certificate of the Guidelines on Foreign Direct Investment
          on the e-commerce sector covered under Press note no 2 (2018 Series)
          released by the Ministry of Commerce and Industry Department of
          Industrial Policy and Promotion dated December 26, 2018.
        </p>
        <h3 className="privacypolicy-div-third-subdiv-heading10">
          Arbitration
        </h3>
        <p>
          This User Agreement shall be construed in accordance with the
          applicable laws of India. The Courts in Mumbai shall have exclusive
          jurisdiction in any proceedings arising out of this agreement. Any
          dispute or difference either in interpretation or otherwise, of any
          terms of this User Agreement between the parties hereto, shall be
          referred to an independent arbitrator who will be appointed by Right
          Solutions Group and their decision shall be final and binding on the
          parties hereto. The above arbitration shall be in accordance with the
          Arbitration and Conciliation Act, 1996 as amended from time to time.
          The arbitration shall be held in Mumbai. The High Court of judicature
          in Mumbai alone shall have the jurisdiction and the Laws of India
          shall apply.
        </p>
        <h3 className="privacypolicy-div-third-subdiv-heading11">Trademarks</h3>
        <p>
          Certain trademarks, trade names and logos used or displayed on the
          Website/ Mobile Application are registered and unregistered
          trademarks, trade names and service marks of MeetMeFit and its
          affiliates. Nothing contained on the Website grants or should be
          construed as granting, by implication, estoppel, or otherwise, any
          license or right to use any trademarks, trade names, service marks or
          logos displayed on the Website without our written permission.
        </p>
        <h3 className="privacypolicy-div-third-subdiv-heading12">
          Other MeetMeFit Sites
        </h3>
        <p>
          MeetMeFit may create and maintain certain websites that are accessible
          outside https://www.meetmefit.com(the “Other Sites”). The Other Sites
          maintain the look and feel of the Services, but are hosted by outside
          service providers with their own terms and privacy policies. If you
          interact with the Other Sites, your information may be stored,
          processed, or shared outside of the Services. If you interact with the
          Other Sites, you acknowledge that you may be subject to the terms and
          conditions and policies applicable to such Other Site. Please be aware
          that any personal information you submit to the Other Sites may be
          read, collected, or used by other users of these forums indefinitely,
          and could be used to send you unsolicited messages. MeetMeFit is not
          responsible for the personal information you choose to submit via the
          Other Sites.
        </p>
        <h3 className="privacypolicy-div-third-subdiv-heading13">
          Privacy Policy Information
        </h3>
        <p>
          MeetMeFit reserves the right to modify this Privacy Policy at any
          time. Please review it occasionally. If MeetMeFit makes changes to
          this Privacy Policy, the updated Privacy Policy will be posted on the
          Services in a timely manner and, if we make material changes, we will
          provide a prominent notice. If you object to any of the changes to
          this Privacy Policy, you should stop using the Services and delete
          your account.
        </p>
        <p>© 2021 MeetMeFit</p>
      </div>
    </div>
  );
}
