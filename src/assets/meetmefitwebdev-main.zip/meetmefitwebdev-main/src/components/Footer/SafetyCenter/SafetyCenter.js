import React from "react";
import "./SafetyCenter.css";

export default function SafetyCenter() {
  return (
    <div className="safetycenter-div container">
      <div className="safetycenter-div-subdiv1 ">
        <h2 className="safetycenter-div-subdiv1-heading1">
          Match & MeetUp Safety Tips
        </h2>
        <p>
          Matching with Fitness Buddies is exciting, but you should always be
          cautious when interacting with someone you don’t know. Use your best
          judgment and put your safety first, whether you are meeting virtually
          or working out in person. While you can’t control the actions of
          others, there are things you can do to help you stay safe during your
          MeetMeFit Experience
        </p>

        <h3 className="safetycenter-div-subdiv1-heading2">Online Safety</h3>

        <h4 className="safetycenter-div-subdiv1-heading3">
          Never Send Money or Share Financial Information
        </h4>
        <p>
          Never send money, especially over wire transfer, even if the person
          claims to be in an emergency. Wiring money is like sending cash — it’s
          nearly impossible to reverse the transaction or trace where the money
          went. Never share information that could be used to access your
          financial accounts. If another user asks you for money, report it to
          us immediately.
        </p>

        <h4 className="safetycenter-div-subdiv1-heading4">
          Protect Your Personal Information
        </h4>
        <p>
          Never share personal information, such as your Government ID numbers,
          home or work address, or details about your daily routine (e.g., that
          you go to a certain gym every Monday) with people you don’t know. If
          you are a parent, limit the information that you share about your
          children on your profile and in early communications. Avoid sharing
          details such as your children’s names, where they go to school, or
          their ages or genders.
        </p>

        <h4 className="safetycenter-div-subdiv1-heading5">
          Stay on the Platform{" "}
        </h4>
        <p>
          Keep conversations on the MeetMeFit platform while you’re getting to
          know someone. Because exchanges on MeetMeFit are subject to our
          access, users with bad intentions often try to move the conversation
          to text, messaging apps, email, or phone right away.
        </p>

        <h4 className="safetycenter-div-subdiv1-heading6">
          Be Wary of Long Distance and Overseas Relationships{" "}
        </h4>
        <p>
          Watch out for scammers who claim to be from your country but stuck
          somewhere else, especially if they ask for financial help to return
          home. Be wary of anyone who will not meet in person or talk on a
          phone/video call—they may not be who they say they are. If someone is
          avoiding your questions - that’s a red flag.
        </p>

        <h4 className="safetycenter-div-subdiv1-heading7">
          Report All Suspicious and Offensive Behavior{" "}
        </h4>
        <p>
          You know when someone’s crossed the line and when they do, we want to
          know about it. Block and report anyone that violates our terms. Here
          are some examples of violations:
          <ul>
            <li>Requests for money or donations</li>
            <li>Underage users</li>
            <li>
              Harassment, threats, and offensive messages Inappropriate or
              harmful behavior during or after meeting in person
            </li>
            <li>Fraudulent profiles</li>
            <li>
              Spam or solicitation including links to commercial websites or
              attempts to sell products or services
            </li>
          </ul>
          <p>
            You can report any concerns about suspicious behavior from any
            profile page
          </p>
        </p>

        <h4 className="safetycenter-div-subdiv1-heading8">
          Protect Your Account
        </h4>
        <p>
          Be sure to pick a strong password, and always be careful when logging
          into your account from a public or shared computer. MeetMeFit will
          never send you an email asking for your username and password
          information — if you receive an email asking for account information,
          report it immediately.
        </p>
      </div>

      <div className="safetycenter-div-subdiv2">
        <h2 className="safetycenter-div-subdiv2-heading1">
          In Person Workouts(Meetups)
        </h2>

        <h4 className="safetycenter-div-subdiv2-heading2">
          Don’t Be In A Rush{" "}
        </h4>
        <p>
          Take your time and get to know the other person before agreeing to
          meet or chat off MeetMeFit. Don’t be afraid to ask questions to screen
          for any red flags or personal dealbreakers. A VMeetup video call can
          be a useful screening tool before meeting.
        </p>

        <h4 className="safetycenter-div-subdiv2-heading3">
          Meet in Public and Stay in Public{" "}
        </h4>
        <p>
          Meet for the first few times in a populated, public place — never at
          your home, your fitness buddy’s home, or any other private location.
          If your fitness buddy pressures you to go to a private location, end
          the Meetup.
        </p>

        <h4 className="safetycenter-div-subdiv2-heading4">
          Tell Friends and Family About Your Plans{" "}
        </h4>
        <p>
          Tell a friend or family member of your plans, including when and where
          you’re going. Have your cell phone charged and with you at all times.
        </p>

        <h4 className="safetycenter-div-subdiv2-heading5">
          Be in Control of Your Transportation{" "}
        </h4>
        <p>
          We want you to be in control of how you get to and from your date so
          that you can leave whenever you want. If you’re driving yourself, it’s
          a good idea to have a backup plan such as a ride-share app or a friend
          to pick you up.
        </p>

        <h4 className="safetycenter-div-subdiv2-heading6">Know Your Limits</h4>
        <p>
          Be aware of the effects of drugs or alcohol on you specifically — they
          can impair your judgment and your alertness. If your fitness buddy
          tries to pressure you to use drugs or drink more than you’re
          comfortable with, hold your ground and end the date.
        </p>

        <h4 className="safetycenter-div-subdiv2-heading7">
          Don’t Leave Drinks or Personal Items Unattended{" "}
        </h4>
        <p>
          Know where your drink comes from and know where it is at all times —
          only accept drinks poured or served directly from the bartender or
          server. Many substances that are slipped into drinks to facilitate
          sexual assault are odorless, colorless, and tasteless. Also, keep your
          phone, purse, wallet, and anything containing personal information on
          you at all times.
        </p>

        <h4 className="safetycenter-div-subdiv2-heading8">
          If You Feel Uncomfortable, Leave{" "}
        </h4>
        <p>
          It’s okay to end the Workout early if you’re feeling uncomfortable. In
          fact, it’s encouraged. And if your instincts are telling you something
          is off or you feel unsafe, ask people around you for help.
        </p>

        <h4 className="safetycenter-div-subdiv2-heading9">LGBTQ+ Travel </h4>
        <p>
          Be careful while traveling We recognise and believe in the importance
          of being inclusive of all gender identities and sexual orientations,
          but the reality is this: nowhere in the world is without potential
          risk, and some countries have specific laws that target LGBTQ+ people.
          Check out the laws around you when you travel to a new place and
          research what types of legal protection, if any, are available to you
          based on sexual orientation. In the event that you’re in unsafe
          territory. It’s important to exercise extra caution if you choose to
          connect with new people in these countries - as some law enforcement
          have been known to use social networking apps as tools for potential
          entrapment.
        </p>
      </div>

      <div className="safetycenter-div-subdiv3">
        <h2 className="safetycenter-div-subdiv3-heading1">
          Workout Limits and Consent{" "}
        </h2>

        <h4 className="safetycenter-div-subdiv3-heading2">Protect Yourself</h4>
        <p>
          Your Fitness Buddy might be the most aesthetically appealing person
          ever but do not follow all workouts suggested by them, sometimes you
          need to just take it slow, use your judgement, be self aware.
          Furthermore, we all love a person that helps us with our reps; Raise
          your voice if your fitness buddy is touching you inappropriately in
          the name of “Spotting” or any other inappropriate gestures, ask for
          help from people around you and end the workout.
        </p>

        <h4 className="safetycenter-div-subdiv3-heading3">
          Talk About Your Limits
        </h4>
        <p>
          Communication is everything: Before you meet your fitness buddies for
          a workout ell them about your experience with workouts and your
          limits, do not unnecessarily try to push your limits, doing too much
          may cause serious injuries.We at MeetMeFit want you to be able to use
          our platform as a means to start, grow and excel in your fitness
          journeys and meet some remarkable people to help and get help from
          along the way. The aforementioned tips may come handy during adverse
          circumstances so always keep them at the back of your mind.
        </p>
        <p className="safetycenter-div-subdiv3-para1">
          We wish you a safe, fruitful and absolutely consistent MeetMeFit
          Community experience! #MakeThisWorldAFitterPlace
        </p>
      </div>
    </div>
  );
}
