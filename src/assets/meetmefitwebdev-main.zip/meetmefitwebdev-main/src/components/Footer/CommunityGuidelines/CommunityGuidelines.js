import React from "react";
import "./CommunityGuidelines.css";

export default function CommunityGuidelines() {
  return (
    <div className="communityguidelines-div container">
      <div className="communityguidelines-div-subdiv1">
        <p className="communityguidelines-div-subdiv1-para1">
          Welcome to the <b>MeetMeFit community</b>. If you’re honest, kind and
          respectful to others, you’ll always be welcome here. If you choose not
          to be, you may not last. Our goal is to allow users to express
          themselves and gain/give value from/to the community freely as long as
          it doesn’t offend others. Everyone is held to the same standard on
          MeetMeFit. We’re asking you to be considerate, think before you act,
          and abide by our community guidelines both on and offline. You heard
          that right: your offline behavior can lead to termination of your
          MeetMeFit account.
        </p>
        <p className="communityguidelines-div-subdiv1-para2">
          Below is a list of our community policies. If you violate any of these
          policies, you might be banned from MeetMeFit. Seriously, don’t make us
          REJECT(X) on you—because there will be no do-overs once we do. We
          encourage you to report any behavior that violates our policies, and
          read up on our Safety Tips.
        </p>
      </div>
      <div className="communityguidelines-div-subdiv2">
        <h1 className="communityguidelines-div-subdiv2-mainheading">
          MeetMeFit is not for:
        </h1>
        <h3 className="communityguidelines-div-subdiv2-heading1">
          Nudity/Sexual Content
        </h3>
        <p>
          We’re not asking you to comb your hair to one side or even speak in
          full sentences; but please keep it classy and appropriate for public
          consumption. No nudity, no sexually explicit content and don’t
          chronicle all of your standards of physical attraction in your bio.
          Keep it clean.
        </p>
        <h3 className="communityguidelines-div-subdiv2-heading2">Harassment</h3>
        <p>
          Do not engage or encourage others to engage in any targeted abuse or
          harassment against any other user. This includes sending any
          unsolicited sexual content to your Fit Buddies (“Matches”). Reports of
          stalking, threats, bullying or intimidation, are taken very seriously.{" "}
        </p>
        <h3 className="communityguidelines-div-subdiv2-heading3">
          Violence and Physical Harm
        </h3>
        <p>
          We do not tolerate violent, graphic or gory content on MeetMeFit.
          Also, any actions or content that advocate for or threaten violence of
          any sort, including threatening or promoting terrorism, physical
          assault, coercion. Any acts of violence are strictly prohibited.
          Content that advocates for or glorifies suicide, self-harm or drug
          abuse is also not allowed. In these situations, we may take a number
          of steps to assist the user, including reaching out with crisis
          resources.
        </p>
        <h3 className="communityguidelines-div-subdiv2-heading4">
          Hate Speech
        </h3>
        <p>
          Any content that promotes, advocates for, or condones racism, bigotry,
          hatred, or violence against individuals or groups based on factors
          like (but not limited to) race, ethnicity, religious affiliation,
          disability, gender, age, national origin, sexual orientation, or
          gender identity is not allowed. ​
        </p>
        <h3 className="communityguidelines-div-subdiv2-heading5">
          Private Information
        </h3>
        <p>
          Don’t publicly broadcast any private information- yours or any Fit
          Buddy’s. This includes PAN / Aadhaar numbers (Or any other government
          documents), passports, passwords, financial information or unlisted
          contact information, such as photos, phone numbers, email addresses,
          home/work address. Private information also includes your personal
          chats/video calls with your Fit Buddy on MeetMeFit.
        </p>
        <h3 className="communityguidelines-div-subdiv2-heading6">Spam</h3>
        <p>
          Don’t be fake. Be real instead. Don’t use MeetMeFit to drive people to
          external websites via a link or otherwise. Promotion or Solicitation
          Soliciting other users is prohibited on MeetMeFit. It’s fine to invite
          your Fit Buddies to something that you’re doing, but if the purpose of
          your profile is to advertise your event or business, non-profit,
          political campaign, contest, or to conduct research, we may delete
          your account.
        </p>
        <h3 className="communityguidelines-div-subdiv2-heading7">
          Prostitution and Trafficking
        </h3>
        <p>
          Promoting or advocating for commercial sexual services, human
          trafficking or other non-consensual sexual acts is strictly prohibited
          and will result in your account being banned from MeetMeFit and
          appropriate legal action could be initiated against.
        </p>
        <h3 className="communityguidelines-div-subdiv2-heading8">Scamming </h3>
        <p>
          MeetMeFit has a zero-tolerance policy on predatory behavior of any
          kind. Anyone attempting to get other users’ private information for
          fraudulent or illegal activity may be banned. Any user caught sharing
          their own financial account information (GPay,UPI, Debit/Credit Card
          Details, etc.) for the purpose of receiving money from other users may
          also be banned from MeetMeFit.
        </p>
        <h3 className="communityguidelines-div-subdiv2-heading9">
          Impersonation{" "}
        </h3>
        <p>
          Be yourself! Don’t pretend to be someone else. Do not impersonate, or
          otherwise misrepresent affiliation, connection or association with,
          any person or entity. This includes parody accounts. While we think
          your celebrity profile is hilarious, you aren’t and having a profile
          like this is prohibited.
        </p>
        <h3 className="communityguidelines-div-subdiv2-heading10">Minors</h3>
        <p>
          You must be 18 years of age or older to use MeetMeFit. As such, we do
          not allow images of unaccompanied minors. If you want to post photos
          of your children, please make sure that you are in the photo as well.
          If you are a child under the age of 18 please make sure you post
          photos that have your parents with you in them. If you see a profile
          that includes an unaccompanied minor, encourages harm to a minor, or
          depicts a minor in a sexual or suggestive way, please report it
          immediately.
        </p>
        <h3 className="communityguidelines-div-subdiv2-heading11">
          Copyright and Trademark Infringement
        </h3>
        <p>
          If it’s not yours, don’t post it. If your MeetMeFit profile includes
          any work that is copyrighted or trademarked by others, don’t display
          it, unless you are allowed to do so.
        </p>
        <h3 className="communityguidelines-div-subdiv2-heading12">
          Illegal Usage
        </h3>
        <p>
          Don’t use MeetMeFit to do anything illegal. If it's illegal in real
          life, it’s illegal on MeetMeFit.
        </p>
        <h3 className="communityguidelines-div-subdiv2-heading13">
          One Person, One Account
        </h3>
        <p>
          MeetMeFit accounts cannot have multiple owners, so don’t create an
          account with your friend or significant other. Additionally, please
          don’t maintain multiple MeetMeFit accounts.
        </p>
        <h3 className="communityguidelines-div-subdiv2-heading14">
          Third Party Apps
        </h3>
        <p>
          The use of any apps created by anyone other than MeetMeFit that claim
          to offer our service or unlock special MeetMeFit features (like
          auto-swipers/bots etc.) is not allowed.
        </p>
        <h3 className="communityguidelines-div-subdiv2-heading15">
          Account Dormancy
        </h3>
        <p>
          MeetMeFit is fun to use... all the time! Use MeetMeFit at the gym, use
          MeetMeFit while listening to music or use MeetMeFit while eating a
          cake. Use MeetMeFit when you’re out, use MeetMeFit when in doubt! But,
          if you don’t log in to your MeetMeFit account in 2 years, we may
          delete your account for inactivity.
        </p>
        <p>
          <b>©2021 MeetMeFit</b>
        </p>
      </div>
    </div>
  );
}
