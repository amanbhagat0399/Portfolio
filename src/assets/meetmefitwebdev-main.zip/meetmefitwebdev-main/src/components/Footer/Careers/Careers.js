import React, { useState } from "react";
import "./Careers.css";
import { app, db } from "../../../Firebase";

export default function Career() {
  //STATES
  const [input, setInput] = useState({
    name: "",
    email: "",
    number: "",
    skills: "",
    message: "",
  });
  const [fileUrl, setFileUrl] = useState(null);

  const [nameError, setNameError] = useState({});
  const [numberError, setNumberError] = useState({});
  const [emailError, setEmailError] = useState({});
  const [skillsError, setSkillsError] = useState({});
  const [uploadError, setUploadError] = useState({});
  const [messageError, setMessageError] = useState({});

  //HANDLING INPUT
  let name, value;
  function handleInput(e) {
    e.preventDefault();
    name = e.target.name;
    value = e.target.value;
    setInput({ ...input, [name]: value });
  }

  //file upload
  async function handleFile(e) {
    e.preventDefault();
    const file = e.target.files[0];
    if (file) {
      let bucketName = "careers-mmf-web";
      const storageRef = app.storage().ref(`${bucketName}/${file.name}`);
      const fileRef = storageRef.child(file.name);
      await fileRef.put(file);
      setFileUrl(await fileRef.getDownloadURL());
      console.log(fileUrl);
    } else {
      setFileUrl(null);
      return false;
    }
  }

  //VALIDATION
  function validation() {
    const { name, email, number, skills, message } = input;

    //LOGIC
    const nameError = {};
    const numberError = {};
    const emailError = {};
    const skillsError = {};
    const uploadError = {};
    const messageError = {};
    let isValid = true;

    //namevalidation
    if (name.length === 0) {
      nameError.empty = "Name is required";
      isValid = false;
    }
    if (name.trim().length > 25) {
      nameError.toolong = "Name is too long";
      isValid = false;
    }

    //namevalidation
    if (number.length === 0) {
      numberError.empty = "Mobile number is required";
      isValid = false;
    } else if (number.length < 10) {
      numberError.tooshort = "Mobile number must be 10 digits";
      isValid = false;
    } else if (number.length > 10) {
      numberError.toolong = "Mobile number must be 10 digits";
      isValid = false;
    }

    //emailvalidation
    if (email.length === 0) {
      emailError.empty = "Email is required";
      isValid = false;
    } else if (!email.includes("@")) {
      emailError.nothave1 = "Email is invalid";
      isValid = false;
    } else if (!email.includes(".")) {
      emailError.nothave2 = "Email is invalid";
      isValid = false;
    } else if (email.indexOf("@") <= 0) {
      emailError.nothave3 = "Email is invalid";
      isValid = false;
    } else if (
      email.charAt(email.length - 4) !== "." &&
      email.charAt(email.length - 3) !== "."
    ) {
      emailError.nothave4 = "Email is invalid";
      isValid = false;
    }

    //skillsvalidation
    if (!skills) {
      skillsError.empty = "Skills is required";
      isValid = false;
    }

    //uploadvalidation
    if (!fileUrl) {
      uploadError.empty = "File is required";
      isValid = false;
    }

    //messagevalidation
    if (!message) {
      messageError.empty = "Message is required";
      isValid = false;
    }
    if (message.trim().length > 150) {
      messageError.toolong = "Message is too long";
      isValid = false;
    }

    setNameError(nameError);
    setNumberError(numberError);
    setEmailError(emailError);
    setSkillsError(skillsError);
    setUploadError(uploadError);
    setMessageError(messageError);
    return isValid;
  }

  //SUBMISSION
  function handleSubmit(e) {
    const { name, email, number, skills, message } = input;

    e.preventDefault();
    const isValid = validation();
    if (isValid === true) {
      //DATABASE QUERY
      db.collection("careers-mmf-web")
        .add({
          name: name,
          email: email,
          number: number,
          skills: skills,
          upload: fileUrl,
          message: message,
        })
        .then((doc) => {
          window.alert("Details Submitted");
        })
        .catch((error) => {
          console.error("Error adding document: ", error);
        });

      //REMOVING INPUTS
      setInput({
        name: "",
        email: "",
        number: "",
        skills: "",
        upload: "",
        message: "",
      });
      setFileUrl("");
    }
  }

  return (
    <div className="career-div container">
      <h1 className="career-heading ">Careers</h1>

      <div className="career-form ">
        <form method="post">
          <div className="container row m-auto">
            <div className="career-subdiv-1 col-sm-12 col-md-12 col-lg-6 ">
              <label
                htmlFor="exampleInputName1"
                className="form-label career-label-1 "
              >
                Name
                <span className="career-form-span-asterik">*</span>
              </label>
              <input
                type="text"
                id="exampleInputName1"
                name="name"
                placeholder="John Doe"
                autoComplete="off"
                value={input.name}
                onChange={handleInput}
                required={true}
                className="form-control career-input-1"
              />
              {Object.keys(nameError).map((x) => {
                return (
                  <div key={x} className="career-input-1-error">
                    {nameError[x]}
                  </div>
                );
              })}
            </div>

            <div className="career-subdiv-2 col-sm-12 col-md-12 col-lg-6 ">
              <label
                htmlFor="exampleInputEmail1"
                className="form-label career-label-2"
              >
                Email address
                <span className="career-form-span-asterik">*</span>
              </label>
              <input
                type="email"
                id="exampleInputEmail1"
                name="email"
                placeholder="Johndoe@email.com"
                autoComplete="off"
                value={input.email}
                onChange={handleInput}
                required={true}
                aria-describedby="emailHelp"
                className="form-control career-input-2"
              />
              {Object.keys(emailError).map((x) => {
                return (
                  <div key={x} className="career-input-2-error">
                    {emailError[x]}
                  </div>
                );
              })}
            </div>

            <div className="career-subdiv-3 col-sm-12 col-md-12 col-lg-6 ">
              <label
                htmlFor="exampleInputNumber1"
                className="form-label career-label-3 "
              >
                Number
                <span className="career-form-span-asterik">*</span>
              </label>
              <input
                type="number"
                name="number"
                id="exampleInputNumber1"
                placeholder="xxx-xxx-xxxx"
                autoComplete="off"
                value={input.number}
                onChange={handleInput}
                required={true}
                className="form-control career-input-3 "
              />
              {Object.keys(numberError).map((x) => {
                return (
                  <div key={x} className="career-input-3-error">
                    {numberError[x]}
                  </div>
                );
              })}
            </div>

            <div className="career-subdiv-4 col-sm-12 col-md-12 col-lg-6 ">
              <label
                htmlFor="exampleInputCompany1"
                className="form-label career-label-4"
              >
                Skills
                <span className="career-form-span-asterik">*</span>
              </label>
              <input
                type="text"
                name="skills"
                id="exampleInputCompany1"
                placeholder="Skills"
                autoComplete="off"
                value={input.skills}
                onChange={handleInput}
                className="form-control career-input-4"
                required={true}
              />
              {Object.keys(skillsError).map((x) => {
                return (
                  <div key={x} className="career-input-4-error">
                    {skillsError[x]}
                  </div>
                );
              })}
            </div>

            <div className="career-subdiv-5 col-sm-12 col-md-12 col-lg-12 ">
              <label
                htmlFor="exampleInputSubject1"
                className="form-label career-label-5"
              >
                Upload
                <span className="career-form-span-asterik">*</span>
              </label>
              <input
                type="file"
                name="upload"
                accept=".pdf"
                id="exampleInputSubject1"
                onChange={handleFile}
                className="form-control career-input-5  "
                required={true}
              />

              {Object.keys(uploadError).map((x) => {
                return (
                  <div key={x} className="career-input-5-error">
                    {uploadError[x]}
                  </div>
                );
              })}
            </div>

            <div className="career-subdiv-6 col-sm-12 col-md-12 col-lg-6 ">
              <label
                htmlFor="exampleFormControlTextarea1"
                className="form-label career-label-6"
              >
                Message
                <span className="career-form-span-asterik">*</span>
              </label>
              <textarea
                name="message"
                id="exampleFormControlTextarea1"
                rows="8"
                cols="8"
                placeholder="Type your Message here.."
                value={input.message}
                onChange={handleInput}
                required={true}
                className="form-control career-input-6 "
              ></textarea>
              {Object.keys(messageError).map((x) => {
                return (
                  <div key={x} className="career-input-6-error">
                    {messageError[x]}
                  </div>
                );
              })}
            </div>
          </div>

          <button
            type="submit"
            className="career-sendButton"
            onClick={handleSubmit}
          >
            Send
          </button>
        </form>
      </div>
      <p className="career-para ">
        <span className="career-para-span1">
          Alternatively, you may also email us at
        </span>
        <span className="career-para-span2">
          <a href="mailto:hello@meetmefit.com" className="career-para-span2-a">
            hello@meetmefit.com
          </a>
        </span>
      </p>
    </div>
  );
}
