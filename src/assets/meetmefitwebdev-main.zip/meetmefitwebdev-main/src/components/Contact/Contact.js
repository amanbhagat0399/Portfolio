import React, { useState, useRef } from "react";
import "./Contact.css";
import { db } from "../../Firebase";
import emailjs from "emailjs-com";

export default function Contact() {
  //STATES
  const [input, setInput] = useState({
    name: "",
    email: "",
    number: "",
    company: "",
    subject: "",
    message: "",
  });

  const [nameError, setNameError] = useState({});
  const [numberError, setNumberError] = useState({});
  const [emailError, setEmailError] = useState({});
  const [companyError, setCompanyError] = useState({});
  const [subjectError, setSubjectError] = useState({});
  const [messageError, setMessageError] = useState({});

  //HANDLING INPUT
  let name, value;
  function handleInput(e) {
    e.preventDefault();
    name = e.target.name;
    value = e.target.value;

    setInput({ ...input, [name]: value });
  }

  //VALIDATION
  function validation() {
    const { name, email, number, company, subject, message } = input;

    //LOGIC
    const nameError = {};
    const numberError = {};
    const emailError = {};
    const companyError = {};
    const subjectError = {};
    const messageError = {};
    let isValid = true;

    //namevalidation
    if (name.length === 0) {
      nameError.empty = "Name is required";
      isValid = false;
    }
    if (name.trim().length > 25) {
      nameError.toolong = "Name is too long";
      isValid = false;
    }

    //namevalidation
    if (number.length === 0) {
      numberError.empty = "Mobile number is required";
      isValid = false;
    } else if (number.length < 10) {
      numberError.tooshort = "Mobile number must be 10 digits";
      isValid = false;
    } else if (number.length > 10) {
      numberError.toolong = "Mobile number must be 10 digits";
      isValid = false;
    }

    //emailvalidation
    if (email.length === 0) {
      emailError.empty = "Email is required";
      isValid = false;
    } else if (!email.includes("@")) {
      emailError.nothave1 = "Email is invalid";
      isValid = false;
    } else if (!email.includes(".")) {
      emailError.nothave2 = "Email is invalid";
      isValid = false;
    } else if (email.indexOf("@") <= 0) {
      emailError.nothave3 = "Email is invalid";
      isValid = false;
    } else if (
      email.charAt(email.length - 4) !== "." &&
      email.charAt(email.length - 3) !== "."
    ) {
      emailError.nothave4 = "Email is invalid";
      isValid = false;
    }

    //companyvalidation
    if (company.length > 45) {
      companyError.toolong = "Company name is too long";
      isValid = false;
    }

    //subjectvalidation
    if (!subject) {
      subjectError.empty = "Subject is required";
      isValid = false;
    }
    if (subject.trim().length > 30) {
      subjectError.toolong = "Subject is too long";
      isValid = false;
    }

    //messagevalidation
    if (!message) {
      messageError.empty = "Message is required";
      isValid = false;
    }
    if (message.trim().length > 150) {
      messageError.toolong = "Message is too long";
      isValid = false;
    }

    setNameError(nameError);
    setNumberError(numberError);
    setEmailError(emailError);
    setCompanyError(companyError);
    setSubjectError(subjectError);
    setMessageError(messageError);
    return isValid;
  }

  //SUBMISSION
  function handleSubmit(e) {
    const { name, email, number, company, subject, message } = input;

    e.preventDefault();
    const isValid = validation();
    if (isValid === true) {
      //DATABASE QUERY
      db.collection("contact-mmf-web")
        .add({
          name: name,
          email: email,
          number: number,
          company: company,
          subject: subject,
          message: message,
        })
        .then((doc) => {
          window.alert("Details Submitted");
          // EMAILJS
          var service_id = "service_u43uxhn";
          var template_id = "template_qb688go";
          var user_id = "user_DmmT54aP5y3WBxODpCKJc";
          var params = {
            to_email: email,
            to_name: name,
          };

          emailjs.send(service_id, template_id, params, user_id).then(
            (result) => {
              console.log(result.text);
            },
            (error) => {
              console.log(error);
            }
          );
        })
        .catch((error) => {
          console.error("Error adding document: ", error);
        });

      //REMOVING INPUTS
      setInput({
        name: "",
        email: "",
        number: "",
        company: "",
        subject: "",
        message: "",
      });
    }
  }

  return (
    <div className="Contact-div container ">
      <h1 className="contact-heading">Message us</h1>

      <div className="Contact-form ">
        <form method="post">
          <div className="container row m-auto">
            <div className="contact-subdiv-1 col-sm-12 col-md-12 col-lg-6 ">
              <label
                htmlFor="exampleInputName1"
                className="form-label contact-label-1"
              >
                Name
                <span className="contact-form-span-asterik">*</span>
              </label>
              <input
                type="text"
                id="exampleInputName1"
                name="name"
                placeholder="John Doe"
                autoComplete="off"
                value={input.name}
                onChange={handleInput}
                required={true}
                className="form-control contact-input-1"
              />
              {Object.keys(nameError).map((x) => {
                return (
                  <div key={x} className="contact-input-1-error">
                    {nameError[x]}
                  </div>
                );
              })}
            </div>

            <div className="contact-subdiv-2 col-sm-12 col-md-12 col-lg-6 ">
              <label
                htmlFor="exampleInputEmail1"
                className="form-label contact-label-2"
              >
                Email address
                <span className="contact-form-span-asterik">*</span>
              </label>
              <input
                type="email"
                id="exampleInputEmail1"
                name="email"
                placeholder="Johndoe@email.com"
                autoComplete="off"
                value={input.email}
                onChange={handleInput}
                required={true}
                aria-describedby="emailHelp"
                className="form-control contact-input-2"
              />
              {Object.keys(emailError).map((x) => {
                return (
                  <div key={x} className="contact-input-2-error">
                    {emailError[x]}
                  </div>
                );
              })}
            </div>

            <div className="contact-subdiv-3 col-sm-12 col-md-12 col-lg-6 ">
              <label
                htmlFor="exampleInputNumber1"
                className="form-label contact-label-3 "
              >
                Number
                <span className="contact-form-span-asterik">*</span>
              </label>
              <input
                type="number"
                name="number"
                id="exampleInputNumber1"
                placeholder="xxx-xxx-xxxx"
                autoComplete="off"
                value={input.number}
                onChange={handleInput}
                required={true}
                className="form-control contact-input-3 "
              />
              {Object.keys(numberError).map((x) => {
                return (
                  <div key={x} className="contact-input-3-error">
                    {numberError[x]}
                  </div>
                );
              })}
            </div>

            <div className="contact-subdiv-4  col-sm-12 col-md-12 col-lg-6 ">
              <label
                htmlFor="exampleInputCompany1"
                className="form-label contact-label-4 "
              >
                Company
              </label>
              <input
                type="text"
                name="company"
                id="exampleInputCompany1"
                placeholder="ABC Company"
                autoComplete="off"
                value={input.company}
                onChange={handleInput}
                className="form-control contact-input-4 "
              />
              {Object.keys(companyError).map((x) => {
                return (
                  <div key={x} className="contact-input-4-error">
                    {companyError[x]}
                  </div>
                );
              })}
            </div>

            <div className="contact-subdiv-5 col-sm-12 col-md-12 col-lg-12 ">
              <label
                htmlFor="exampleInputSubject1"
                className="form-label contact-label-5"
              >
                Subject
                <span className="contact-form-span-asterik">*</span>
              </label>
              <input
                type="text"
                name="subject"
                id="exampleInputSubject1"
                placeholder="Subject"
                autoComplete="off"
                value={input.subject}
                onChange={handleInput}
                className="form-control contact-input-5 "
                required={true}
              />
              {Object.keys(subjectError).map((x) => {
                return (
                  <div key={x} className="contact-input-5-error">
                    {subjectError[x]}
                  </div>
                );
              })}
            </div>

            <div className="contact-subdiv-6  col-sm-12 col-md-12 col-lg-6 ">
              <label
                htmlFor="exampleFormControlTextarea1"
                className="form-label contact-label-6"
              >
                Message
                <span className="contact-form-span-asterik">*</span>
              </label>
              <textarea
                name="message"
                id="exampleFormControlTextarea1"
                rows="8"
                cols="8"
                placeholder="Type your Message here.."
                value={input.message}
                onChange={handleInput}
                required={true}
                className="form-control contact-input-6 "
              ></textarea>
              {Object.keys(messageError).map((x) => {
                return (
                  <div key={x} className="contact-input-6-error">
                    {messageError[x]}
                  </div>
                );
              })}
            </div>
          </div>

          <button
            type="submit"
            className="contact-sendButton"
            onClick={handleSubmit}
          >
            Send
          </button>
        </form>
      </div>
      <p className="contact-para">
        <span className="contact-para-span1">
          Alternatively, you may also email us at
        </span>
        <span className="contact-para-span2">
          <a href="mailto:hello@meetmefit.com" className="contact-para-span2-a">
            hello@meetmefit.com
          </a>
        </span>
      </p>
    </div>
  );
}
