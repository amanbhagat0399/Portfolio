import React from "react";
import "./ErrorPage.css";
import { useHistory } from "react-router-dom";

export default function ErrorPage() {
  const history = useHistory();

  function handleClick() {
    let path = "/";
    history.push(path);
  }
  return (
    <div className="errorpage-div container">
      <h1 className="errorpage-div-heading">404</h1>
      <p className="errorpage-div-para1">Ooops!!</p>
      <p className="errorpage-div-para2">
        THAT PAGE DOESN'T EXIST OR IS UNAVAILABLE.
      </p>
      <button className="errorpage-div-button" onClick={handleClick}>
        Go back to Home
      </button>
    </div>
  );
}
